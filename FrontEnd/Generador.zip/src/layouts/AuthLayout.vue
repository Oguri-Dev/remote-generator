<template>
  <div class="auth-wrapper">
    <slot />
  </div>
</template>
