<script setup lang="ts">
import { useViewWrapper } from "/@src/stores/viewWrapper"
import { useMqttStore } from '/@src/stores/MqttStore';
import PrincipalViewComponent from "/@src/components/pages/generador/PrincipalViewComponent.vue";
const mqtt = useMqttStore()
const viewWrapper = useViewWrapper()
viewWrapper.setPageTitle('Generador Control')

onBeforeMount(() => {

})

useHead({
    title: 'Generador Control',
})
</script>

<template>
    <div class="page-content-inner">
        <PrincipalViewComponent />
    </div>
</template>

<style lang="scss">
::-webkit-scrollbar {
    display: none;
}
</style>